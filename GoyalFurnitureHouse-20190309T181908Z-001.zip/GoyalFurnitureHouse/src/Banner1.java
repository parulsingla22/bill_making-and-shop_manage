
import java.awt.Color;

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Banner1 extends JPanel implements Runnable 
{
	JLabel l1,l2;
	
	public Banner1() {
		setLayout(new FlowLayout(FlowLayout.CENTER));

		l1=new JLabel(" ...WELCCOME TO GOYAL FURNITURE HOUSE ... ");
		//l1.setOpaque(true);
		
		l1.setFont(new Font("Algerian",Font.BOLD|Font.ITALIC,40));
		l1.setForeground(new Color(255,255,255));
                setBackground(new Color(0,200,200));
		add(l1);
		setSize(100,50);
		setVisible(true);
		Thread th=new Thread(this);
		th.start();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//new Banner();
	}

	@Override
	public void run() 
	{
		while(true)
		{

			String str=l1.getText();
			char c=str.charAt(0);
			str=str.substring(1,str.length())+c;
			l1.setText(str);
			try
			{
				Thread.sleep(1000);
			}
			catch (Exception e) {
				JOptionPane.showMessageDialog(null, e.getMessage());
			}
		}
	}
	
}
