/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Muskan
 */
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class Connect {
    
    Connection con;
    Statement s;
    
    Connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/Shop","root","aes.Pi");
            s=con.createStatement();
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
    }  
    
    public String customer_id()
    {
        String cid="";
        try {
            ResultSet rs=s.executeQuery("select * from customer");
            if(rs.last())
            {
                String s=rs.getString(1);
                s=s.substring(1, s.length());
                
                int n=Integer.parseInt(s);
               // JOptionPane.showMessageDialog(null, n);
                n++;
                cid="c"+n;
            }
            else
            {
                cid="c1001";
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        return  cid;
    }
    
    public int updatedata(String q)
    {
    int n=0;    
    
        try {
            n=s.executeUpdate(q);
            //con.close();
        } 
        catch (SQLException ex) {
          JOptionPane.showMessageDialog(null, ex.getMessage());
        }
  
    return n;
    }
    
    public boolean checklogin(String q)
    {
        
        boolean b=false;
        ResultSet rs=null;
        
        try
        {
        rs=s.executeQuery(q);
    
    if(rs.next())
    {
     b=true;   
    }
        }
        
        catch (SQLException ex) 
        {
           JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        
        
    return b;
    }
    
    public int bill_id()
    {
        int bid=0;
        try {
            ResultSet rs=s.executeQuery("select * from bill");
            if(rs.last())
            {
                 bid=rs.getInt(1);   
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, ex.getMessage());
        }
        return  bid;
    }
    public ResultSet showCustomer(String str)
    {
        ResultSet rs=null;
        try {
            rs=s.executeQuery(str);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
                
        return rs;
    }
public void FillTable(JTable table, String Query)
{
    try
    {
        ResultSet rs = this.showCustomer(Query);

         DefaultTableModel tableModel = new DefaultTableModel();

        //Retrieve meta data from ResultSet
        ResultSetMetaData metaData = rs.getMetaData();

        //Get number of columns from meta data
        int columnCount = metaData.getColumnCount();

        //Get all column names from meta data and add columns to table model
        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++){
            tableModel.addColumn(metaData.getColumnLabel(columnIndex));
        }

        //Create array of Objects with size of column count from meta data
        Object[] row = new Object[columnCount];

        //Scroll through result set
        while (rs.next()){
            //Get object from column with specific index of result set to array of objects
            for (int i = 0; i < columnCount; i++){
                row[i] = rs.getObject(i+1);
            }
            //Now add row to table model with that array of objects as an argument
            tableModel.addRow(row);
        }

        //Now add that table model to your table and you are done :D
        table.setModel(tableModel);
        
    }
    catch(Exception e)
    {
        JOptionPane.showMessageDialog(null, e.getMessage());
    }
}
}    

