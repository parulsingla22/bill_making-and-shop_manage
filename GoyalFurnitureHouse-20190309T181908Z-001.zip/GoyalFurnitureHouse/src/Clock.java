import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.util.*;
import javax.swing.*;
public class Clock extends JPanel implements Runnable 
{
	
	JLabel l1;
	public Clock() {
		// TODO Auto-generated constructor stub
		setLayout(new FlowLayout(FlowLayout.RIGHT));
		l1=new JLabel("");
		l1.setFont(new Font("Algerian",Font.BOLD|Font.ITALIC,20));
		l1.setForeground(new Color(0,153,153));
                setBackground(Color.white);
		add(l1);
		setSize(100,100);
		setVisible(true);
		Thread th=new Thread(this);
		th.start();
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//new Clock();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true)
		{
			Calendar c=Calendar.getInstance();
			int h=c.get(Calendar.HOUR);
			int m=c.get(Calendar.MINUTE);
			int s=c.get(Calendar.SECOND);
			
			String h1=check(h);
			String m1=check(m);
			String s1=check(s);
			
			String str=h1+":"+m1+":"+s1;
			l1.setText(str);
			try
			{
				Thread.sleep(1000);
			}
			catch (Exception e) {
				// TODO: handle exception
			}
		}
	}
	public String check(int a)
	{
		if(a<=9)
		{
			return "0"+a;
		}
		return String.valueOf(a);
	}

}