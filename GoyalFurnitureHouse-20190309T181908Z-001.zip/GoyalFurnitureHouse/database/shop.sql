-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.27-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema shop
--

CREATE DATABASE IF NOT EXISTS shop;
USE shop;

--
-- Definition of table `attendance`
--

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `Aid` int(11) NOT NULL auto_increment,
  `id` varchar(30) default NULL,
  `Date` varchar(20) default NULL,
  `present_absent` varchar(20) default NULL,
  PRIMARY KEY  (`Aid`),
  KEY `id` (`id`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`id`) REFERENCES `worker` (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance`
--

/*!40000 ALTER TABLE `attendance` DISABLE KEYS */;
INSERT INTO `attendance` (`Aid`,`id`,`Date`,`present_absent`) VALUES 
 (1,'W2','2017-07-10','present'),
 (2,'W1','2017-07-10','present'),
 (3,'W1','27/6/2017','present'),
 (4,'W2','27/6/2017','present'),
 (5,'W4','27/6/2017','absent'),
 (6,'W3','27/6/2017','absent'),
 (7,'W1','18/07/2017','present'),
 (8,'W1','27/6/2017','present'),
 (9,'W2','27/6/2017','present'),
 (10,'W4','27/6/2017','absent'),
 (11,'W3','27/6/2017','absent'),
 (12,'W1','28/6/2017','present'),
 (13,'W2','28/6/2017','absent'),
 (14,'W3','28/6/2017','present'),
 (15,'W4','28/6/2017','absent');
/*!40000 ALTER TABLE `attendance` ENABLE KEYS */;


--
-- Definition of table `bill`
--

DROP TABLE IF EXISTS `bill`;
CREATE TABLE `bill` (
  `BId` int(11) NOT NULL auto_increment,
  `CId` varchar(10) NOT NULL,
  `Product` varchar(50) NOT NULL,
  `quantity` varchar(10) NOT NULL,
  `Total` varchar(20) NOT NULL,
  PRIMARY KEY  (`BId`),
  KEY `CId` (`CId`),
  CONSTRAINT `bill_ibfk_1` FOREIGN KEY (`CId`) REFERENCES `customer` (`CId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill`
--

/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` (`BId`,`CId`,`Product`,`quantity`,`Total`) VALUES 
 (1,'c1005','Bed','1','12800'),
 (2,'c1005','Bed','1','12800'),
 (3,'c1006','Bed','1','1280'),
 (4,'c1006','Bed','1','1280'),
 (5,'c1002','Table,Chair','5','16768'),
 (6,'c1002','Bed,Chair','6','40960'),
 (7,'c1001','Bed','1','12800'),
 (8,'c1007','Bed','1','12800');
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;


--
-- Definition of table `bill_detail`
--

DROP TABLE IF EXISTS `bill_detail`;
CREATE TABLE `bill_detail` (
  `Bill_id` int(11) NOT NULL auto_increment,
  `BId` int(11) NOT NULL,
  `Products` varchar(50) NOT NULL,
  `Quantity` varchar(20) NOT NULL,
  `Price` varchar(50) NOT NULL,
  `Total` varchar(20) default NULL,
  PRIMARY KEY  (`Bill_id`),
  KEY `BId` (`BId`),
  CONSTRAINT `bill_detail_ibfk_1` FOREIGN KEY (`BId`) REFERENCES `bill` (`BId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bill_detail`
--

/*!40000 ALTER TABLE `bill_detail` DISABLE KEYS */;
INSERT INTO `bill_detail` (`Bill_id`,`BId`,`Products`,`Quantity`,`Price`,`Total`) VALUES 
 (1,1,'Bed','1','10000','12800'),
 (2,2,'Bed','1','10000','12800'),
 (3,3,'Bed','1','1000','1280'),
 (4,4,'Bed','1','1000','1280'),
 (5,5,'Table','1','10000','12800'),
 (6,5,'Chair','4','300+900+1000+900','3968'),
 (7,6,'Bed','2','10000+20000','38400'),
 (8,6,'Chair','4','500+500+500+500','2560'),
 (9,7,'Bed','1','10000','12800'),
 (10,8,'Bed','1','10000','12800');
/*!40000 ALTER TABLE `bill_detail` ENABLE KEYS */;


--
-- Definition of table `customer`
--

DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `CId` varchar(10) NOT NULL,
  `Name` varchar(35) NOT NULL,
  `Address` text,
  `Phone` varchar(10) NOT NULL,
  PRIMARY KEY  (`CId`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` (`CId`,`Name`,`Address`,`Phone`) VALUES 
 ('c1001','jdhc','kjhdj','100000'),
 ('c1002','jdhc','kjhdj','100000'),
 ('c1003','','',''),
 ('c1004','','asdf','2345'),
 ('c1005','parul','sangrur',''),
 ('c1006','parul','sangrur',''),
 ('c1007','parul','','');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;


--
-- Definition of table `info`
--

DROP TABLE IF EXISTS `info`;
CREATE TABLE `info` (
  `Type` varchar(10) NOT NULL,
  `Username` varchar(35) NOT NULL,
  `Password` varchar(20) NOT NULL,
  PRIMARY KEY  (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `info`
--

/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` (`Type`,`Username`,`Password`) VALUES 
 ('admin','Muskan','8787878');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;


--
-- Definition of table `worker`
--

DROP TABLE IF EXISTS `worker`;
CREATE TABLE `worker` (
  `ID` varchar(10) NOT NULL,
  `Name` varchar(35) NOT NULL,
  `Age` varchar(10) default NULL,
  `Phone` varchar(10) NOT NULL,
  `Address` varchar(100) NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `worker`
--

/*!40000 ALTER TABLE `worker` DISABLE KEYS */;
INSERT INTO `worker` (`ID`,`Name`,`Age`,`Phone`,`Address`) VALUES 
 ('','','','',''),
 ('W1','hari','20','1234','qwert'),
 ('W2','sham','19','1234','qaz'),
 ('W3','ram','23','7890','a'),
 ('W4','asd','12','12345','cvbn'),
 ('W5','abc','10','1234','sangrur');
/*!40000 ALTER TABLE `worker` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
